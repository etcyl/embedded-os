ECE 362
2/1/2019
Matt Fleetwood
Assignment 2

Here you will find two directories: end and capture.
Change directories to /end or /capture for the end.c or capture.c programs, respectively.

To compile a program, type make all in the command line of the terminal.

To run the program, type ./NAME in the terminal, where NAME is the program (end or capture).

To delete the program, type make clean in the command line of the terminal.

PROGRAM DESCRIPTIONS

END.c
Accepts a filename and an optional n integer as input to the program.
If the filename does not exist, an error message is printed to stdout.
If the filename exists and n is larger than 0 but less than 10, the 
last n lines from the file are displayed to stdout.
If n is less than 1 or greater than 9, an error is shown to stdout.
If file exists but n is not specified, then the last 5 lines of the
file are displayed to stdout.

For example, the file could look like the following:

"characters on the first line"
"some more chars here"
"third line"
"fourth and last line for this file"

In this case, if the user did not specify n, assuming this file is valid then the last 5 lines
in the file are printed (using system write) by default. Since only 4 lines exist here, only the last 4 are shown.
If the user specified n (as argv[2]) as 2, then because this file has 4 lines only the last two lines
are written to STDOUT_FILENO, i.e.:

"third line"
"fourth and last line for this file"


CAPTURE.C
Accepts a filename (e.g. filename.txt) that includes a list of commads, one per line, to 
execute. Each command is executed by a subprocess (using fork and execvp). The output
of each subprocess is written to the file capture.txt.

For instance, a commandfile.txt might look like the following:

wc -l capture.c
ls
uname -r
...

In this case, the first line (wc -l capture.c) is executed by a subprocess, which runs
the wordcount program, using -l, for the program capture.c and finally the output 
(in this case wordcount of the file capture.c) is written to the file ./CAPTURE.
Next, another subprocess is executed for the ls command on the second line of this file.
After the ls output is written to the ./CAPTURE file, the last line is proccessed, in this
case uname -r, and then its output is appended to ./CAPTURE as before with the other
subprocesses.